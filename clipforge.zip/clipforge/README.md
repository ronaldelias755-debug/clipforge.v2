# ClipForge

Alternativa open-source y self-hosted a OpusClip. Vídeo largo -> clips verticales 9:16 con subtítulos animados.

## Pipeline
ingest -> transcribe (faster-whisper) -> highlights (LLM) -> reframe (MediaPipe) -> subtitles (ASS) -> render (FFmpeg)

## Instalación local
```bash
# requiere ffmpeg en el PATH y Python 3.10+
pip install -e ".[cloud,dev]"
cp .env.example .env
ollama pull qwen2.5:14b-instruct      # modo local
```

## Uso
```bash
clipforge analyze mi_podcast.mp4 -n 5          # solo propone highlights
clipforge run mi_podcast.mp4 -n 5 --min 25 --max 60
clipforge run "https://youtu.be/XXXX" --provider anthropic --model claude-sonnet-5-5
```
Salida: `workspace/<job>/clips/*.mp4` + `transcript.json` + `highlights.json` (editable; se reutilizan como caché).

## Docker
```bash
docker compose up -d ollama && docker compose exec ollama ollama pull qwen2.5:14b-instruct
docker compose run --rm clipforge run /input/podcast.mp4 -n 5
```

## Tests
`pytest`
