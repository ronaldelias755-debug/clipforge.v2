from clipforge.highlights.analyzer import virality
from clipforge.highlights.llm import extract_json
from clipforge.models import Scores, Word
from clipforge.subtitles.ass import build_ass


def test_extract_json_with_fences():
    assert extract_json('```json\n{"clips": []}\n```') == {"clips": []}


def test_virality_weights_sum_to_one():
    assert virality(Scores(hook=100, retention=100, value=100, emotion=100, shareability=100, standalone=100)) == 100.0


def test_ass_has_one_event_per_word():
    words = [Word(text=t, start=i * 0.4, end=i * 0.4 + 0.35) for i, t in enumerate("esto es muy importante".split())]
    ass = build_ass(words, clip_start=0.0, keywords=["importante"])
    assert ass.count("Dialogue:") == 4
