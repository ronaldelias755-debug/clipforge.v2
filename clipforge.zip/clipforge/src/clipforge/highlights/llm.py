"""Capa de abstracción de LLM: Ollama (local), Anthropic u OpenAI. Todos devuelven un dict JSON."""
from __future__ import annotations

import json
import re
from typing import Protocol

import httpx

from clipforge.config import Settings


class LLM(Protocol):
    def complete_json(self, system: str, user: str) -> dict: ...


def extract_json(text: str) -> dict:
    """Tolera ```json fences o texto extra alrededor del objeto."""
    text = re.sub(r"```(?:json)?", "", text).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"El LLM no devolvió JSON: {text[:200]!r}")
    return json.loads(text[start : end + 1])


class OllamaLLM:
    def __init__(self, s: Settings):
        self.s = s

    def complete_json(self, system: str, user: str) -> dict:
        r = httpx.post(
            f"{self.s.ollama_url}/api/chat",
            json={
                "model": self.s.llm_model,
                "stream": False,
                "format": "json",
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "options": {"temperature": self.s.llm_temperature, "num_ctx": 16384},
            },
            timeout=600,
        )
        r.raise_for_status()
        return extract_json(r.json()["message"]["content"])


class AnthropicLLM:
    def __init__(self, s: Settings):
        import anthropic

        self.s = s
        self.client = anthropic.Anthropic()  # lee ANTHROPIC_API_KEY

    def complete_json(self, system: str, user: str) -> dict:
        msg = self.client.messages.create(
            model=self.s.llm_model,
            max_tokens=4096,
            temperature=self.s.llm_temperature,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return extract_json("".join(b.text for b in msg.content if b.type == "text"))


class OpenAILLM:
    def __init__(self, s: Settings):
        from openai import OpenAI

        self.s = s
        self.client = OpenAI()  # lee OPENAI_API_KEY

    def complete_json(self, system: str, user: str) -> dict:
        r = self.client.chat.completions.create(
            model=self.s.llm_model,
            temperature=self.s.llm_temperature,
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
        )
        return extract_json(r.choices[0].message.content)


def get_llm(s: Settings) -> LLM:
    return {"ollama": OllamaLLM, "anthropic": AnthropicLLM, "openai": OpenAILLM}[s.llm_provider](s)
