from clipforge.highlights.analyzer import find_highlights

__all__ = ["find_highlights"]
