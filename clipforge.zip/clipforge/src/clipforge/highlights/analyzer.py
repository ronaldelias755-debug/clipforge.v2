"""Detección de highlights: ventanas -> LLM -> validación -> snap a frases -> ranking -> dedupe."""
from __future__ import annotations

import logging

from clipforge.config import Settings
from clipforge.highlights.llm import LLM, get_llm
from clipforge.highlights.prompts import build_system_prompt, build_user_prompt
from clipforge.models import Highlight, Scores, Transcript

log = logging.getLogger("clipforge.highlights")

# Pesos de la nota final de viralidad (suman 1.0). El hook manda: decide el scroll.
WEIGHTS = {"hook": 0.30, "retention": 0.20, "value": 0.15, "emotion": 0.12,
           "shareability": 0.13, "standalone": 0.10}


def virality(scores: Scores) -> float:
    d = scores.model_dump()
    return round(sum(d[k] * w for k, w in WEIGHTS.items()), 1)


def _window_lines(t: Transcript, w_start: float, w_end: float) -> str:
    return "\n".join(f"[{s.start:.1f}] {s.text}" for s in t.segments if s.end > w_start and s.start < w_end)


def _snap(t: Transcript, start: float, end: float, min_s: float, max_s: float) -> tuple[float, float] | None:
    """Ajusta a límites de frase reales para no cortar a mitad de palabra/oración."""
    segs = t.segments
    if not segs:
        return None
    s_seg = min(segs, key=lambda s: abs(s.start - start))
    start = s_seg.start
    cands = [s for s in segs if s.end > start]
    e_seg = min(cands, key=lambda s: abs(s.end - end))
    end = e_seg.end
    while end - start > max_s:
        prev = [s for s in cands if s.end < end and s.end - start <= max_s]
        if not prev:
            return None
        end = prev[-1].end
    start = max(0.0, start - 0.15)
    end = min(t.duration, end + 0.25)
    return (start, end) if end - start >= min_s * 0.8 else None


def _overlap(a: Highlight, b: Highlight) -> float:
    inter = max(0.0, min(a.end, b.end) - max(a.start, b.start))
    return inter / max(1e-6, min(a.duration, b.duration))


def find_highlights(
    t: Transcript, s: Settings, n_clips: int = 5, min_s: int = 20, max_s: int = 60, llm: LLM | None = None
) -> list[Highlight]:
    llm = llm or get_llm(s)
    system = build_system_prompt(min_s, max_s, max_clips=max(3, n_clips))
    candidates: list[Highlight] = []

    step = s.window_s - s.window_overlap_s
    w_start = 0.0
    while w_start < t.duration:
        w_end = min(t.duration, w_start + s.window_s)
        lines = _window_lines(t, w_start, w_end)
        if lines.strip():
            try:
                data = llm.complete_json(system, build_user_prompt(lines, w_start, w_end, t.duration))
            except Exception as e:  # una ventana fallida no debe tumbar el job
                log.warning("Ventana %.0f-%.0f falló: %s", w_start, w_end, e)
                data = {"clips": []}
            for c in data.get("clips", []):
                try:
                    snapped = _snap(t, float(c["start"]), float(c["end"]), min_s, max_s)
                    if not snapped:
                        continue
                    sc = Scores(**{k: float(v) for k, v in c.get("scores", {}).items() if k in Scores.model_fields})
                    candidates.append(Highlight(
                        start=snapped[0], end=snapped[1], title=c.get("title", "Clip")[:90],
                        hook=c.get("hook", ""), summary=c.get("summary", ""), reason=c.get("reason", ""),
                        keywords=[str(k) for k in c.get("keywords", [])], scores=sc, virality_score=virality(sc),
                    ))
                except (KeyError, ValueError, TypeError) as e:
                    log.warning("Clip descartado por formato inválido: %s", e)
        if w_end >= t.duration:
            break
        w_start += step

    # Ranking + dedupe (las ventanas solapadas generan duplicados)
    candidates.sort(key=lambda h: h.virality_score, reverse=True)
    chosen: list[Highlight] = []
    for h in candidates:
        if all(_overlap(h, o) < 0.3 for o in chosen):
            chosen.append(h)
        if len(chosen) >= n_clips:
            break
    return chosen
