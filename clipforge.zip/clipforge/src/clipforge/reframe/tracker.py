"""Reencuadre inteligente 16:9 -> 9:16 siguiendo al hablante.

1. Detecta caras a ~5 fps (MediaPipe; fallback a Haar de OpenCV).
2. Elige un objetivo con histéresis (evita saltar entre caras en cada frame).
3. Interpola a todos los frames y suaviza con gaussiana (offline => sin retardo).
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from clipforge.config import Settings


@dataclass
class CropPlan:
    fps: float
    start_frame: int
    src_w: int
    src_h: int
    crop_w: int
    crop_h: int
    xs: np.ndarray  # x izquierda del recorte por frame
    y: int


class FaceDetector:
    def __init__(self):
        self._mp = None
        try:
            import mediapipe as mp

            self._mp = mp.solutions.face_detection.FaceDetection(model_selection=1, min_detection_confidence=0.5)
        except Exception:
            self._haar = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    def detect(self, bgr: np.ndarray) -> list[tuple[float, float]]:
        """Devuelve [(centro_x_px, area_px)] en coordenadas del frame original."""
        h, w = bgr.shape[:2]
        scale = 640 / w if w > 640 else 1.0
        small = cv2.resize(bgr, None, fx=scale, fy=scale) if scale != 1.0 else bgr
        faces: list[tuple[float, float]] = []
        if self._mp is not None:
            res = self._mp.process(cv2.cvtColor(small, cv2.COLOR_BGR2RGB))
            for d in res.detections or []:
                b = d.location_data.relative_bounding_box
                faces.append(((b.xmin + b.width / 2) * w, b.width * w * b.height * h))
        else:
            for x, y, fw, fh in self._haar.detectMultiScale(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY), 1.1, 5):
                faces.append(((x + fw / 2) / scale, (fw / scale) * (fh / scale)))
        return faces


def _even(v: float) -> int:
    return int(round(v / 2)) * 2


def plan_crop(video, start: float, end: float, s: Settings) -> CropPlan:
    cap = cv2.VideoCapture(str(video))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    crop_w = min(w, _even(h * 9 / 16))
    crop_h = min(h, _even(crop_w * 16 / 9))
    f0, f1 = int(start * fps), int(end * fps)
    n = max(1, f1 - f0)

    step = max(1, int(round(fps / s.face_sample_fps)))
    detector = FaceDetector()
    cap.set(cv2.CAP_PROP_POS_FRAMES, f0)
    sample_idx: list[int] = []
    sample_cx: list[float] = []
    prev_cx: float | None = None
    for i in range(n):
        if i % step:
            if not cap.grab():
                break
            continue
        ok, frame = cap.read()
        if not ok:
            break
        faces = detector.detect(frame)
        if faces:
            if prev_cx is None:
                cx = max(faces, key=lambda f: f[1])[0]
            else:
                # histéresis: favorece la cara más cercana a la anterior
                cx = max(faces, key=lambda f: f[1] * (1.6 if abs(f[0] - prev_cx) < w * 0.15 else 1.0))[0]
            prev_cx = cx
            sample_idx.append(i)
            sample_cx.append(cx)
    cap.release()

    frames = np.arange(n)
    if sample_idx:
        centers = np.interp(frames, sample_idx, sample_cx)
        sigma = max(1.0, s.camera_smooth_s * fps)
        radius = int(sigma * 3)
        kernel = np.exp(-0.5 * (np.arange(-radius, radius + 1) / sigma) ** 2)
        kernel /= kernel.sum()
        centers = np.convolve(np.pad(centers, radius, mode="edge"), kernel, mode="valid")
    else:
        centers = np.full(n, w / 2)  # sin caras: centro
    xs = np.clip(centers - crop_w / 2, 0, w - crop_w).astype(int)
    return CropPlan(fps, f0, w, h, crop_w, crop_h, xs, (h - crop_h) // 2)
