"""Configuración central. Todo se puede sobreescribir con variables CLIPFORGE_* o .env."""
from __future__ import annotations

from pathlib import Path
from typing import Literal, Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CLIPFORGE_", env_file=".env", extra="ignore")

    workspace: Path = Path("workspace")

    # Transcripción
    whisper_model: str = "large-v3"
    whisper_device: str = "auto"
    whisper_compute_type: str = "default"
    language: Optional[str] = None  # None = autodetectar

    # LLM
    llm_provider: Literal["ollama", "anthropic", "openai"] = "ollama"
    llm_model: str = "qwen2.5:14b-instruct"
    ollama_url: str = "http://localhost:11434"
    llm_temperature: float = 0.3

    # Análisis de highlights (ventanas deslizantes sobre la transcripción)
    window_s: float = 600.0
    window_overlap_s: float = 60.0

    # Salida
    out_width: int = 1080
    out_height: int = 1920

    # Reencuadre
    face_sample_fps: float = 5.0
    camera_smooth_s: float = 0.6  # sigma del suavizado gaussiano de la cámara


settings = Settings()
