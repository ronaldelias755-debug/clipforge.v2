"""Subtítulos animados estilo karaoke (formato ASS, renderizado por libass vía FFmpeg).

Se agrupan 1-3 palabras por línea; por cada palabra hablada se emite un evento que muestra el
grupo con la palabra activa resaltada y con un pequeño 'pop'. Las palabras clave del LLM se
pintan siempre con otro color.
"""
from __future__ import annotations

import re

from clipforge.models import Word

# ASS usa BGR: &HBBGGRR&
ACTIVE, KEYWORD = "&H00E5FF&", "&H50E650&"

HEADER = """[Script Info]
ScriptType: v4.00+
PlayResX: {w}
PlayResY: {h}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Montserrat ExtraBold,{size},&H00FFFFFF,&H000000FF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,7,2,2,60,60,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def _ts(t: float) -> str:
    cs = int(round(max(0.0, t) * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def _group(words: list[Word], max_words: int = 3, max_chars: int = 22, max_gap: float = 0.6) -> list[list[Word]]:
    groups: list[list[Word]] = []
    cur: list[Word] = []
    for w in words:
        if cur and (len(cur) >= max_words or sum(len(x.text) for x in cur) + len(w.text) > max_chars
                    or w.start - cur[-1].end > max_gap):
            groups.append(cur)
            cur = []
        cur.append(w)
        if re.search(r"[.!?,;:]$", w.text):
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    return groups


def _norm(s: str) -> str:
    return re.sub(r"[^\w]", "", s.lower())


def build_ass(words: list[Word], clip_start: float, keywords: list[str], width: int = 1080,
              height: int = 1920, font_size: int = 88, uppercase: bool = True) -> str:
    kw = {_norm(p) for k in keywords for p in k.split()}
    out = [HEADER.format(w=width, h=height, size=font_size, margin_v=int(height * 0.27))]
    groups = _group(words)
    for gi, g in enumerate(groups):
        next_start = groups[gi + 1][0].start if gi + 1 < len(groups) else None
        for wi, active in enumerate(g):
            start = active.start - clip_start
            end = g[wi + 1].start - clip_start if wi + 1 < len(g) else active.end - clip_start + 0.15
            if wi + 1 == len(g) and next_start is not None:
                end = min(end, next_start - clip_start)
            end = max(end, start + 0.06)
            parts = []
            for j, w in enumerate(g):
                txt = w.text.replace("{", "(").replace("}", ")")
                txt = txt.upper() if uppercase else txt
                if j == wi:
                    parts.append(r"{\c" + ACTIVE + r"\fscx100\fscy100\t(0,90,\fscx118\fscy118)}" + txt + r"{\r}")
                elif _norm(w.text) in kw:
                    parts.append(r"{\c" + KEYWORD + "}" + txt + r"{\r}")
                else:
                    parts.append(txt)
            out.append(f"Dialogue: 0,{_ts(start)},{_ts(end)},Default,,0,0,0,,{' '.join(parts)}")
    return "\n".join(out) + "\n"
