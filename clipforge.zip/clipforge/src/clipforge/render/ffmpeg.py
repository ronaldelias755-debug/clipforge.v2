"""Render final: frames recortados (OpenCV) -> pipe rawvideo -> FFmpeg (+ subtítulos ASS + audio)."""
from __future__ import annotations

import subprocess
from pathlib import Path

import cv2

from clipforge.config import Settings
from clipforge.reframe.tracker import CropPlan


def render_clip(video: Path, plan: CropPlan, start: float, end: float, ass_file: Path,
                out_path: Path, s: Settings) -> Path:
    out_w, out_h = s.out_width, s.out_height
    cmd = [
        "ffmpeg", "-y", "-loglevel", "error",
        "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{out_w}x{out_h}", "-r", f"{plan.fps}", "-i", "-",
        "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(video),
        "-map", "0:v:0", "-map", "1:a:0?",
        "-vf", f"ass={ass_file.name}",  # se ejecuta con cwd=carpeta del .ass (evita escapes)
        "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k", "-shortest", "-movflags", "+faststart",
        str(out_path.resolve()),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, cwd=ass_file.parent)
    cap = cv2.VideoCapture(str(video))
    cap.set(cv2.CAP_PROP_POS_FRAMES, plan.start_frame)
    try:
        for x in plan.xs:
            ok, frame = cap.read()
            if not ok:
                break
            crop = frame[plan.y : plan.y + plan.crop_h, x : x + plan.crop_w]
            proc.stdin.write(cv2.resize(crop, (out_w, out_h), interpolation=cv2.INTER_AREA).tobytes())
    except BrokenPipeError:
        pass
    finally:
        cap.release()
        if proc.stdin:
            proc.stdin.close()
        rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"FFmpeg terminó con código {rc}")
    return out_path
