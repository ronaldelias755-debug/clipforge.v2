"""Orquestador del pipeline. Cada etapa cachea su resultado en el directorio del job."""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path

from rich.console import Console

from clipforge.config import Settings
from clipforge.highlights import find_highlights
from clipforge.ingest import extract_audio, ingest, make_job_id
from clipforge.models import Highlight, Transcript
from clipforge.reframe import plan_crop
from clipforge.render import render_clip
from clipforge.subtitles import build_ass
from clipforge.transcribe import get_transcriber

console = Console()
log = logging.getLogger("clipforge")


def _slug(text: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "-", text).strip("-").lower()[:40] or "clip"


class Pipeline:
    def __init__(self, settings: Settings):
        self.s = settings

    def analyze(self, source: str, n_clips=5, min_s=20, max_s=60, force=False):
        """Etapas 1-3: ingestión, transcripción y highlights. Devuelve (job_dir, video, transcript, highlights)."""
        job_dir = self.s.workspace / make_job_id(source)
        console.log(f"[bold]1/3 Ingestión[/] -> {job_dir}")
        video = ingest(source, job_dir)
        audio = extract_audio(video, job_dir / "audio.wav")

        t_path = job_dir / "transcript.json"
        if t_path.exists() and not force:
            transcript = Transcript.model_validate_json(t_path.read_text())
            console.log("2/3 Transcripción (cache)")
        else:
            console.log("[bold]2/3 Transcripción[/]")
            transcript = get_transcriber(self.s).transcribe(audio)
            t_path.write_text(transcript.model_dump_json(indent=1))

        h_path = job_dir / "highlights.json"
        if h_path.exists() and not force:
            highlights = [Highlight(**h) for h in json.loads(h_path.read_text())]
            console.log("3/3 Highlights (cache)")
        else:
            console.log(f"[bold]3/3 Highlights[/] con {self.s.llm_provider}:{self.s.llm_model}")
            highlights = find_highlights(transcript, self.s, n_clips, min_s, max_s)
            h_path.write_text(json.dumps([h.model_dump() for h in highlights], indent=1, ensure_ascii=False))
        return job_dir, video, transcript, highlights

    def run(self, source: str, n_clips=5, min_s=20, max_s=60, force=False) -> list[Path]:
        job_dir, video, transcript, highlights = self.analyze(source, n_clips, min_s, max_s, force)
        clips_dir = job_dir / "clips"
        clips_dir.mkdir(exist_ok=True)
        outputs: list[Path] = []
        for i, h in enumerate(highlights, 1):
            console.log(f"[bold]Clip {i}/{len(highlights)}[/] {h.title} ({h.duration:.0f}s, score {h.virality_score})")
            stem = f"clip_{i:02d}_{_slug(h.title)}"
            ass = clips_dir / f"clip_{i:02d}.ass"
            ass.write_text(
                build_ass(transcript.words_between(h.start, h.end), h.start, h.keywords,
                          self.s.out_width, self.s.out_height),
                encoding="utf-8",
            )
            plan = plan_crop(video, h.start, h.end, self.s)
            outputs.append(render_clip(video, plan, h.start, h.end, ass, clips_dir / f"{stem}.mp4", self.s))
        console.log(f"[green]Listo:[/] {len(outputs)} clips en {clips_dir}")
        return outputs
