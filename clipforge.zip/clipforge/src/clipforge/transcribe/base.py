from __future__ import annotations

from pathlib import Path
from typing import Protocol

from clipforge.config import Settings
from clipforge.models import Transcript


class Transcriber(Protocol):
    """Interfaz común. Para AssemblyAI/Deepgram basta con otra clase que devuelva Transcript."""

    def transcribe(self, audio: Path) -> Transcript: ...


def get_transcriber(settings: Settings) -> Transcriber:
    from clipforge.transcribe.faster_whisper_backend import FasterWhisperTranscriber

    return FasterWhisperTranscriber(settings)
