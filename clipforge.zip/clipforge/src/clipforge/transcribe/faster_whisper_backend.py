"""Transcripción local con faster-whisper y timestamps por palabra."""
from __future__ import annotations

from pathlib import Path

from rich.progress import Progress

from clipforge.config import Settings
from clipforge.models import Segment, Transcript, Word


class FasterWhisperTranscriber:
    def __init__(self, settings: Settings):
        self.s = settings

    def transcribe(self, audio: Path) -> Transcript:
        from faster_whisper import WhisperModel

        model = WhisperModel(
            self.s.whisper_model,
            device=self.s.whisper_device,
            compute_type=self.s.whisper_compute_type,
        )
        segments_iter, info = model.transcribe(
            str(audio),
            language=self.s.language,
            word_timestamps=True,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 500},
            beam_size=5,
        )
        segments: list[Segment] = []
        with Progress() as progress:
            task = progress.add_task("Transcribiendo", total=info.duration)
            for i, seg in enumerate(segments_iter):
                words = [Word(text=w.word.strip(), start=w.start, end=w.end, prob=w.probability)
                         for w in (seg.words or [])]
                segments.append(Segment(id=i, start=seg.start, end=seg.end, text=seg.text.strip(), words=words))
                progress.update(task, completed=seg.end)
        return Transcript(language=info.language, duration=info.duration, segments=segments)
