"""CLI: `clipforge run <video|url>` o `clipforge analyze <video|url>` (sin renderizar)."""
from __future__ import annotations

import typer
from rich.table import Table

from clipforge.config import settings
from clipforge.pipeline import Pipeline

app = typer.Typer(help="ClipForge: vídeos largos -> clips virales verticales", no_args_is_help=True)


def _apply(provider, model, whisper, language):
    if provider: settings.llm_provider = provider
    if model: settings.llm_model = model
    if whisper: settings.whisper_model = whisper
    if language: settings.language = language


@app.command()
def run(
    source: str = typer.Argument(..., help="Ruta local o URL (YouTube, etc.)"),
    clips: int = typer.Option(5, "--clips", "-n"),
    min_s: int = typer.Option(20, "--min"),
    max_s: int = typer.Option(60, "--max"),
    provider: str = typer.Option(None, help="ollama | anthropic | openai"),
    model: str = typer.Option(None, help="Modelo LLM"),
    whisper: str = typer.Option(None, help="tiny/small/medium/large-v3"),
    language: str = typer.Option(None, help="Código ISO (es, en...). Por defecto autodetecta"),
    force: bool = typer.Option(False, help="Ignorar caché"),
):
    """Pipeline completo: transcribe, detecta highlights, reencuadra, subtitula y renderiza."""
    _apply(provider, model, whisper, language)
    Pipeline(settings).run(source, clips, min_s, max_s, force)


@app.command()
def analyze(
    source: str,
    clips: int = typer.Option(5, "--clips", "-n"),
    min_s: int = typer.Option(20, "--min"),
    max_s: int = typer.Option(60, "--max"),
    provider: str = typer.Option(None),
    model: str = typer.Option(None),
    whisper: str = typer.Option(None),
    language: str = typer.Option(None),
    force: bool = typer.Option(False),
):
    """Solo transcribe y propone highlights (barato: revisa antes de renderizar)."""
    _apply(provider, model, whisper, language)
    *_, highlights = Pipeline(settings).analyze(source, clips, min_s, max_s, force)
    table = Table("#", "Inicio", "Fin", "Score", "Título")
    for i, h in enumerate(highlights, 1):
        table.add_row(str(i), f"{h.start:.1f}", f"{h.end:.1f}", str(h.virality_score), h.title)
    typer.echo("")
    from rich.console import Console
    Console().print(table)


if __name__ == "__main__":
    app()
