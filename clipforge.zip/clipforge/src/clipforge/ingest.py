"""Ingestión: archivo local o URL (yt-dlp) -> vídeo + audio 16 kHz mono para Whisper."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path


def make_job_id(source: str) -> str:
    stem = re.sub(r"[^a-zA-Z0-9]+", "-", Path(source).stem if "://" not in source else "url").strip("-")[:30]
    return f"{stem or 'job'}-{hashlib.sha1(source.encode()).hexdigest()[:8]}"


def ingest(source: str, job_dir: Path) -> Path:
    """Devuelve la ruta al vídeo local (descarga si es URL)."""
    job_dir.mkdir(parents=True, exist_ok=True)
    if re.match(r"https?://", source):
        target = job_dir / "source.mp4"
        if not target.exists():
            from yt_dlp import YoutubeDL

            opts = {
                "format": "bv*[height<=1080]+ba/b[height<=1080]/b",
                "merge_output_format": "mp4",
                "outtmpl": str(job_dir / "source.%(ext)s"),
                "quiet": True,
                "noprogress": True,
            }
            with YoutubeDL(opts) as ydl:
                ydl.download([source])
        return target
    path = Path(source).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def probe(video: Path) -> dict:
    out = subprocess.check_output(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,r_frame_rate:format=duration",
         "-of", "json", str(video)]
    )
    d = json.loads(out)
    num, den = d["streams"][0]["r_frame_rate"].split("/")
    return {
        "width": d["streams"][0]["width"],
        "height": d["streams"][0]["height"],
        "fps": float(num) / float(den),
        "duration": float(d["format"]["duration"]),
    }


def extract_audio(video: Path, out: Path) -> Path:
    if not out.exists():
        subprocess.run(
            ["ffmpeg", "-y", "-loglevel", "error", "-i", str(video),
             "-vn", "-ac", "1", "-ar", "16000", str(out)],
            check=True,
        )
    return out
