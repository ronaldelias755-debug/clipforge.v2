"""Modelos de datos compartidos entre módulos (pydantic v2)."""
from __future__ import annotations

from pydantic import BaseModel, Field


class Word(BaseModel):
    text: str
    start: float
    end: float
    prob: float = 1.0


class Segment(BaseModel):
    id: int
    start: float
    end: float
    text: str
    words: list[Word] = Field(default_factory=list)


class Transcript(BaseModel):
    language: str
    duration: float
    segments: list[Segment]

    def words_between(self, start: float, end: float) -> list[Word]:
        return [w for s in self.segments for w in s.words if w.end > start and w.start < end]


class Scores(BaseModel):
    """Subpuntuaciones 0-100 que devuelve el LLM. La nota final se calcula en código."""
    hook: float = 0
    retention: float = 0
    value: float = 0
    emotion: float = 0
    shareability: float = 0
    standalone: float = 0


class Highlight(BaseModel):
    start: float
    end: float
    title: str
    hook: str = ""
    summary: str = ""
    reason: str = ""
    keywords: list[str] = Field(default_factory=list)
    scores: Scores = Field(default_factory=Scores)
    virality_score: float = 0.0

    @property
    def duration(self) -> float:
        return self.end - self.start
